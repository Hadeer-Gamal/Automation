$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("API_Request.feature");
formatter.feature({
  "line": 1,
  "name": "Test API",
  "description": "",
  "id": "test-api",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Check GET API request will show all data",
  "description": "",
  "id": "test-api;check-get-api-request-will-show-all-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "API Request that GET all user Data",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "I assert on the status code success",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "I asset on response Body size",
  "keyword": "And "
});
formatter.match({
  "location": "ApiStepDef.api_Request_that_GET_all_user_Data()"
});
formatter.result({
  "duration": 3270250300,
  "status": "passed"
});
formatter.match({
  "location": "ApiStepDef.i_assert_on_the_status_code_success()"
});
formatter.result({
  "duration": 4743900,
  "status": "passed"
});
formatter.match({
  "location": "ApiStepDef.i_asset_on_response_Body_size()"
});
formatter.result({
  "duration": 323620200,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 9,
  "name": "Check GET API request will show data BY ID",
  "description": "",
  "id": "test-api;check-get-api-request-will-show-data-by-id",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "API Request that GET Data By \"\u003cID\u003e\"",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "I assert on the status code success",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "I asset on response of user  \"\u003cID\u003e\"",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "test-api;check-get-api-request-will-show-data-by-id;",
  "rows": [
    {
      "cells": [
        "ID"
      ],
      "line": 14,
      "id": "test-api;check-get-api-request-will-show-data-by-id;;1"
    },
    {
      "cells": [
        "1"
      ],
      "line": 15,
      "id": "test-api;check-get-api-request-will-show-data-by-id;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "Check GET API request will show data BY ID",
  "description": "",
  "id": "test-api;check-get-api-request-will-show-data-by-id;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "API Request that GET Data By \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "I assert on the status code success",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "I asset on response of user  \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 30
    }
  ],
  "location": "ApiStepDef.api_Request_that_GET_Data_By(String)"
});
formatter.result({
  "duration": 336182100,
  "status": "passed"
});
formatter.match({
  "location": "ApiStepDef.i_assert_on_the_status_code_success()"
});
formatter.result({
  "duration": 74200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 30
    }
  ],
  "location": "ApiStepDef.i_asset_on_response_of_user(String)"
});
formatter.result({
  "duration": 872651900,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 17,
  "name": "Check Post API request will Create new user",
  "description": "",
  "id": "test-api;check-post-api-request-will-create-new-user",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 18,
  "name": "API Request Create new user api with \"\u003ctitle\u003e\" and \"\u003cuserBody\u003e\" and \"\u003cuserID\u003e\"",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "I assert on the success code of creation",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "I asset on response \"\u003cuserID\u003e\"",
  "keyword": "And "
});
formatter.examples({
  "line": 21,
  "name": "",
  "description": "",
  "id": "test-api;check-post-api-request-will-create-new-user;",
  "rows": [
    {
      "cells": [
        "title",
        "userBody",
        "userID"
      ],
      "line": 22,
      "id": "test-api;check-post-api-request-will-create-new-user;;1"
    },
    {
      "cells": [
        "testUserTitle",
        "TestuserBody",
        "101"
      ],
      "line": 23,
      "id": "test-api;check-post-api-request-will-create-new-user;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 23,
  "name": "Check Post API request will Create new user",
  "description": "",
  "id": "test-api;check-post-api-request-will-create-new-user;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 18,
  "name": "API Request Create new user api with \"testUserTitle\" and \"TestuserBody\" and \"101\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "I assert on the success code of creation",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "I asset on response \"101\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "testUserTitle",
      "offset": 38
    },
    {
      "val": "TestuserBody",
      "offset": 58
    },
    {
      "val": "101",
      "offset": 77
    }
  ],
  "location": "ApiStepDef.api_Request_Create_new_user_api_with_and_and(String,String,String)"
});
formatter.result({
  "duration": 621459700,
  "status": "passed"
});
formatter.match({
  "location": "ApiStepDef.i_assert_on_the_success_code_of_creation()"
});
formatter.result({
  "duration": 101300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "101",
      "offset": 21
    }
  ],
  "location": "ApiStepDef.i_asset_on_response(String)"
});
formatter.result({
  "duration": 19394600,
  "status": "passed"
});
});