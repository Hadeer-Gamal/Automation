package APIStepDef;

import java.util.List;

import org.testng.Assert;

import APIRequests.UsersEndpoints;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ApiStepDef extends UsersEndpoints{
    Response response;
    
@Given("^API Request that GET all user Data$")
public void api_Request_that_GET_all_user_Data() throws Throwable {
	response = UsersEndpoints.getUsersRequest();
}

@Then("^I assert on the status code success$")
public void i_assert_on_the_status_code_success() throws Throwable {
    int statusCode = response.getStatusCode();
    Assert.assertEquals(statusCode, 200);
}

@Then("^I asset on response Body size$")
public void i_asset_on_response_Body_size() throws Throwable {
	   List<String> usersList = response.jsonPath().getList("$");
       int usersSize = usersList.size();
       Assert.assertEquals(usersSize, 100);
}

@Given("^API Request that GET Data By \"([^\"]*)\"$")
public void api_Request_that_GET_Data_By(String ID) throws Throwable {
	System.out.println(ID);
	response = UsersEndpoints.getUserByIdRequest(ID);
}

@Then("^I asset on response of user  \"([^\"]*)\"$")
public void i_asset_on_response_of_user(String id) throws Throwable {
	String jsonString = response.getBody().asString(); //Convert response to string
	  System.out.println(jsonString);
    String actualid = JsonPath.from(jsonString).get("id").toString();
	Assert.assertTrue(actualid.equals(id));
}

@Given("^API Request Create new user api with \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
public void api_Request_Create_new_user_api_with_and_and(String title, String body, String userId) throws Throwable {
	response = UsersEndpoints.createUserRequest(title, body, userId);
}

@Then("^I assert on the success code of creation$")
public void i_assert_on_the_success_code_of_creation() throws Throwable {
	   int statusCode = response.getStatusCode();
	   System.out.println(statusCode);
       Assert.assertEquals(statusCode, 201);
}

@Then("^I asset on response \"([^\"]*)\"$")
public void i_asset_on_response(String userId) throws Throwable {
	 String jsonString = response.getBody().asString(); //Convert response to string
	 System.out.println(jsonString);
     String  actualUserId = JsonPath.from(jsonString).get("id").toString();
     Assert.assertEquals(actualUserId,userId);
}

}