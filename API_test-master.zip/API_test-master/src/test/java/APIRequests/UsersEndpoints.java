package APIRequests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
public class UsersEndpoints {
    static String baseURL = "https://jsonplaceholder.typicode.com";
    static String getUsersEndpoint = "/posts";
    static Response response;
    
    
    public static String constructBody(String title, String userbody, String userId) {
       String body = "         {​​​\n" +
                "            \"title\":\""+ title +"\",\n" +
                "            \"body\":\""+ userbody +"\",\n" +
                "            \"userId\":\""+ userId +"\",\n" +
                "         }​​​,\n";
        return body;
   }
    
    public static Response getUsersRequest()
    {
        try {
            RestAssured.baseURI = baseURL+getUsersEndpoint;
            response = given().get(); //Send header parameters
            System.out.println("Get All users status code is "+ response.getStatusCode());
        } catch (Exception e) { e.printStackTrace(); }
        return response;
    }
    
    public static Response getUserByIdRequest(String id)
    {
        try {
            RestAssured.baseURI = baseURL+getUsersEndpoint;
            response = given().get("/"+id); //Send header parameters
            System.out.println("Get User data By ID status code is "+ response.getStatusCode());
        } catch (Exception e) { e.printStackTrace(); }
        return response;
    }
    
    public static Response createUserRequest(String title, String userbody, String userId) {
     
      	try {
			String body = constructBody(title, userbody, userId);
			RestAssured.baseURI = baseURL+getUsersEndpoint;
			response = given()
			            .body(body).post(); //Send header parameters
			System.out.println("create user status code is "+ response.getStatusCode());
		} catch (Exception e) {
			
			e.printStackTrace();
		}
          return response;
	
    }

      
    //=====================================Test our code using main============================
    /*
    public static void main( String[] args )
    {
        UsersEndpoints usersEndpoints = new UsersEndpoints();
       // usersEndpoints.getUsersRequest();
      //  usersEndpoints.getUserByIdRequest("3");
        usersEndpoints.createUserRequest("test user", "user body", "101");
    }
  */
}