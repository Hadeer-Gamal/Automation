package com.AutomationTask.Driver;


public class BaseTest {
	protected DriverSingleTone driverSingletone=DriverSingleTone.getDriverSingleton();

}
