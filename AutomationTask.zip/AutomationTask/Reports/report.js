$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("LoginPage.feature");
formatter.feature({
  "line": 2,
  "name": "Login Actions",
  "description": "",
  "id": "login-actions",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Run"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "User can Login successfully with valid user and pass",
  "description": "",
  "id": "login-actions;user-can-login-successfully-with-valid-user-and-pass",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User can Navigate to WebSite",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter Username \"\u003cUser\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enter Password \"\u003cPassword\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User Login Successfully",
  "keyword": "Then "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "login-actions;user-can-login-successfully-with-valid-user-and-pass;",
  "rows": [
    {
      "cells": [
        "User",
        "Password"
      ],
      "line": 11,
      "id": "login-actions;user-can-login-successfully-with-valid-user-and-pass;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123"
      ],
      "line": 12,
      "id": "login-actions;user-can-login-successfully-with-valid-user-and-pass;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 203924500,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "User can Login successfully with valid user and pass",
  "description": "",
  "id": "login-actions;user-can-login-successfully-with-valid-user-and-pass;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Run"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User can Navigate to WebSite",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter Username \"Admin\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enter Password \"admin123\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User Login Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginPageStepdef.user_can_Navigate_to_WebSite()"
});
formatter.result({
  "duration": 6915051400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 16
    }
  ],
  "location": "LoginPageStepdef.enter_Username(String)"
});
formatter.result({
  "duration": 144597400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin123",
      "offset": 16
    }
  ],
  "location": "LoginPageStepdef.enter_Password(String)"
});
formatter.result({
  "duration": 91214300,
  "status": "passed"
});
formatter.match({
  "location": "LoginPageStepdef.user_Login_Successfully()"
});
formatter.result({
  "duration": 3867007200,
  "status": "passed"
});
formatter.after({
  "duration": 2700934200,
  "status": "passed"
});
formatter.uri("Users.feature");
formatter.feature({
  "line": 2,
  "name": "UserPage  Actions",
  "description": "",
  "id": "userpage--actions",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Run"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "User can Navigate to UsersPage successfully",
  "description": "",
  "id": "userpage--actions;user-can-navigate-to-userspage-successfully",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User can Navigate to WebSite",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter Username \"\u003cUser\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enter Password \"\u003cPassword\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User Login Successfully",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "User can Open Users Page",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "userpage--actions;user-can-navigate-to-userspage-successfully;",
  "rows": [
    {
      "cells": [
        "User",
        "Password"
      ],
      "line": 12,
      "id": "userpage--actions;user-can-navigate-to-userspage-successfully;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123"
      ],
      "line": 13,
      "id": "userpage--actions;user-can-navigate-to-userspage-successfully;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 36144700,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "User can Navigate to UsersPage successfully",
  "description": "",
  "id": "userpage--actions;user-can-navigate-to-userspage-successfully;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Run"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User can Navigate to WebSite",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter Username \"Admin\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enter Password \"admin123\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User Login Successfully",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "User can Open Users Page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginPageStepdef.user_can_Navigate_to_WebSite()"
});
formatter.result({
  "duration": 5762725200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 16
    }
  ],
  "location": "LoginPageStepdef.enter_Username(String)"
});
formatter.result({
  "duration": 102889700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin123",
      "offset": 16
    }
  ],
  "location": "LoginPageStepdef.enter_Password(String)"
});
formatter.result({
  "duration": 107839300,
  "status": "passed"
});
formatter.match({
  "location": "LoginPageStepdef.user_Login_Successfully()"
});
formatter.result({
  "duration": 3731167400,
  "status": "passed"
});
formatter.match({
  "location": "NavigationStepdef.user_can_Open_Users_Page()"
});
formatter.result({
  "duration": 1538756300,
  "status": "passed"
});
formatter.after({
  "duration": 2271472300,
  "status": "passed"
});
});