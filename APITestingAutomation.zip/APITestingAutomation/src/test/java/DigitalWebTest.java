import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import com.fasterxml.jackson.databind.util.JSONPObject;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.response.ValidatableResponse;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers.*;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

import java.util.HashMap;
import java.util.Map;

public class DigitalWebTest {


    @Test
    public void testGuruAPI() throws JSONException {
        String url="http://demo.guru99.com/V4/sinkministatement.php?CUSTOMER_ID=68195&PASSWORD=1234!&Account_No=1";
        RestAssured.baseURI = "http://demo.guru99.com";

        Response res =
                given().
                    queryParams("CUSTOMER_ID", "68195").
                    queryParams("PASSWORD", "1234!").
                    queryParams("Account_No", "1").
                when().
                    get("/V4/sinkministatement.php");

        System.out.println(res.statusCode());
        System.out.println(res.time());
        System.out.println(res.body().asString());
        System.out.println(res.header("Content-Type"));

        SoftAssert softAssertion = new SoftAssert();
        softAssertion.assertTrue(res.statusCode() == 200);
        softAssertion.assertTrue(res.time() < 2000);
        softAssertion.assertTrue(res.body().asString().contains("TRANSACTION_ID"));
        softAssertion.assertTrue(res.header("Content-Type").contains("text"));
        softAssertion.assertAll();
    }

    @Test
    public void testMusicAPI() throws JSONException {
        String url="https://genius.p.rapidapi.com/artists/16775/songs";
        RestAssured.baseURI = "https://genius.p.rapidapi.com";

        Response res =
                given().
                    header("x-rapidapi-host", "genius.p.rapidapi.com").
                    header("x-rapidapi-key", "6b1c678a28msh9b2353697242286p13dfd3jsna9ae979df1d1").
                when().
                    get("/artists/16775/songs");

        System.out.println(res.statusCode());
        System.out.println(res.time());
        System.out.println(res.body().asString());
        System.out.println(res.header("Content-Type"));

        SoftAssert softAssertion = new SoftAssert();
        softAssertion.assertTrue(res.statusCode() == 200, Integer.toString(res.statusCode())+": status code not 300 OK");
        softAssertion.assertTrue(res.time() < 250, Double.toString(res.time())+": Response time greater than 2000");
        softAssertion.assertTrue(res.body().asString().contains("sample body"), "Body does not contain 'sample body'");
        softAssertion.assertTrue(res.header("Content-Type").contains("json"));
        softAssertion.assertAll();
    }


}
